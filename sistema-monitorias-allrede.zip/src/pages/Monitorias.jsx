import React, { useState, useContext } from 'react'
import { UserContext } from '../App'

const initialDemo = [
  {
    id: 1,
    data: '2025-10-25',
    colaborador: 'NICOLLE VIEIRA BISPO',
    supervisor: 'QUESIA',
    ticket: '13636741',
    protocolo: '540889',
    descricao: 'Registro incorreto - mudança de endereço registrado como atendimento',
    pontosPositivos: 'Atendimento educado',
    observacoes: '',
    resultado: 'Retido',
    assinaturaColaborador: '',
    assinaturaSupervisor: ''
  }
]

export default function Monitorias() {
  const { user } = useContext(UserContext)
  const [rows, setRows] = useState(initialDemo)
  const [form, setForm] = useState({
    data: '', colaborador: '', supervisor: '', ticket: '', protocolo: '', descricao: '', pontosPositivos: '', observacoes: '', resultado: ''
  })

  function handleCreate(e) {
    e.preventDefault()
    const newRow = { ...form, id: Date.now() }
    setRows([newRow, ...rows])
    setForm({ data: '', colaborador: '', supervisor: '', ticket: '', protocolo: '', descricao: '', pontosPositivos: '', observacoes: '', resultado: '' })
  }

  function toggleAssinarCol(id) {
    setRows(rows.map(r => r.id === id ? { ...r, assinaturaColaborador: 'Assinado em ' + new Date().toLocaleString() } : r))
  }

  function toggleAssinarSup(id) {
    setRows(rows.map(r => r.id === id ? { ...r, assinaturaSupervisor: 'Assinado em ' + new Date().toLocaleString() } : r))
  }

  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Monitorias</h2>
      <form onSubmit={handleCreate} className="bg-white p-4 rounded shadow mb-6 grid grid-cols-2 gap-3">
        <div>
          <label className="text-sm">Data (SOMENTE ANALISTA)</label>
          <input value={form.data} onChange={e => setForm({ ...form, data: e.target.value })} className="w-full border rounded px-2 py-1" placeholder="YYYY-MM-DD" />
        </div>
        <div>
          <label className="text-sm">Colaborador</label>
          <input value={form.colaborador} onChange={e => setForm({ ...form, colaborador: e.target.value })} className="w-full border rounded px-2 py-1" />
        </div>
        <div>
          <label className="text-sm">Supervisor (auto)</label>
          <input value={form.supervisor} onChange={e => setForm({ ...form, supervisor: e.target.value })} className="w-full border rounded px-2 py-1" />
        </div>
        <div>
          <label className="text-sm">Ticket / Nº ligação</label>
          <input value={form.ticket} onChange={e => setForm({ ...form, ticket: e.target.value })} className="w-full border rounded px-2 py-1" />
        </div>
        <div>
          <label className="text-sm">Protocolo</label>
          <input value={form.protocolo} onChange={e => setForm({ ...form, protocolo: e.target.value })} className="w-full border rounded px-2 py-1" />
        </div>
        <div className="col-span-2">
          <label className="text-sm">Descrição da Monitoria</label>
          <textarea value={form.descricao} onChange={e => setForm({ ...form, descricao: e.target.value })} className="w-full border rounded px-2 py-1" rows={3}></textarea>
        </div>
        <div>
          <label className="text-sm">Pontos Positivos</label>
          <input value={form.pontosPositivos} onChange={e => setForm({ ...form, pontosPositivos: e.target.value })} className="w-full border rounded px-2 py-1" />
        </div>
        <div>
          <label className="text-sm">Resultado</label>
          <select value={form.resultado} onChange={e => setForm({ ...form, resultado: e.target.value })} className="w-full border rounded px-2 py-1">
            <option value="">--</option>
            <option value="Retido">Retido</option>
            <option value="Não Retido">Não Retido</option>
          </select>
        </div>

        <div className="col-span-2 text-right">
          <button className="px-4 py-2 bg-allredeOrange text-white rounded">Criar Monitoria</button>
        </div>
      </form>

      <div className="space-y-3">
        {rows.map(r => (
          <div key={r.id} className="bg-white p-4 rounded shadow">
            <div className="flex justify-between items-start">
              <div>
                <div className="text-sm text-gray-500">{r.data} • {r.colaborador} • {r.supervisor}</div>
                <h4 className="font-semibold">Ticket: {r.ticket} • Protocolo: {r.protocolo}</h4>
                <p className="mt-2">{r.descricao}</p>
                <p className="mt-1 text-sm text-green-700">Pontos positivos: {r.pontosPositivos}</p>
                <p className="mt-1 text-sm">Observações: {r.observacoes}</p>
              </div>
              <div className="text-right">
                <div className={`inline-block px-3 py-1 rounded text-white ${r.resultado === 'Retido' ? 'bg-red-500' : 'bg-green-600'}`}>{r.resultado || '—'}</div>
                <div className="mt-3">
                  <div className="text-xs">Assinatura Colab:</div>
                  {r.assinaturaColaborador ? <div className="text-sm text-gray-600">{r.assinaturaColaborador}</div> : <button onClick={() => toggleAssinarCol(r.id)} className="mt-1 px-2 py-1 bg-allredeMid text-white rounded text-xs">Assinar</button>}
                </div>
                <div className="mt-3">
                  <div className="text-xs">Assinatura Sup:</div>
                  {r.assinaturaSupervisor ? <div className="text-sm text-gray-600">{r.assinaturaSupervisor}</div> : <button onClick={() => toggleAssinarSup(r.id)} className="mt-1 px-2 py-1 bg-allredeDark text-white rounded text-xs">Assinar</button>}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
