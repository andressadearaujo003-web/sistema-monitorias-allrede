import React from 'react'

export default function Usuarios() {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Usuários</h2>
      <p>Gerenciamento de usuários (criação de contas, associação supervisor - colaborador). Nesta versão demo, os usuários são estáticos.</p>
    </div>
  )
}
