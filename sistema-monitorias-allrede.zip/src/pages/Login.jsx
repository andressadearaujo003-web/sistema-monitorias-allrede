import React, { useContext, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { UserContext } from '../App'

const demoUsers = [
  { username: 'analista', password: 'Analista123', role: 'analista', displayName: 'Andressa (Analista)' },
  { username: 'quesia', password: 'Qesia123', role: 'supervisor', displayName: 'Quesia (Supervisor)' },
  { username: 'matheus', password: 'Matheus123', role: 'supervisor', displayName: 'Matheus (Supervisor)' },
  { username: 'beatriz', password: 'Beatriz123', role: 'supervisor', displayName: 'Beatriz (Supervisor)' },
  { username: 'colab1', password: 'Colab123', role: 'colaborador', displayName: 'Colaborador Exemplo' }
]

export default function Login() {
  const { setUser } = useContext(UserContext)
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [error, setError] = useState('')
  const navigate = useNavigate()

  function handleLogin(e) {
    e.preventDefault()
    const found = demoUsers.find(u => u.username === username && u.password === password)
    if (!found) {
      setError('Usuário ou senha inválidos (use as credenciais de demonstração).')
      return
    }
    setUser(found)
    navigate('/app')
  }

  return (
    <div className="min-h-screen flex items-center justify-center">
      <div className="w-full max-w-md bg-white shadow p-6 rounded">
        <div className="text-center mb-4">
          <img src="/idehR-ka1b_logos.png" alt="Allrede" className="w-36 mx-auto" />
          <h1 className="text-xl font-semibold mt-2">Sistema de Monitorias - Retenção Allrede Telecom</h1>
        </div>
        <form onSubmit={handleLogin} className="space-y-3">
          <div>
            <label className="text-sm">Usuário</label>
            <input value={username} onChange={e => setUsername(e.target.value)} className="w-full border rounded px-3 py-2" />
          </div>
          <div>
            <label className="text-sm">Senha</label>
            <input type="password" value={password} onChange={e => setPassword(e.target.value)} className="w-full border rounded px-3 py-2" />
          </div>
          {error && <div className="text-sm text-red-600">{error}</div>}
          <button type="submit" className="w-full bg-allredeDark text-white py-2 rounded">Entrar</button>
        </form>

        <div className="mt-4 text-xs text-gray-600">
          Credenciais de demonstração:<br />analista / Analista123 — quesia / Qesia123 — matheus / Matheus123 — beatriz / Beatriz123 — colab1 / Colab123
        </div>
      </div>
    </div>
  )
}
