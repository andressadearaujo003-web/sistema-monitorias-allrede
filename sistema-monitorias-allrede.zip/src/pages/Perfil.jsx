import React, { useContext } from 'react'
import { UserContext } from '../App'

export default function Perfil() {
  const { user } = useContext(UserContext)
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4">Meu Perfil</h2>
      <div className="bg-white p-4 rounded shadow">
        <div className="text-sm text-gray-600">Nome</div>
        <div className="font-medium">{user?.displayName || '--'}</div>
        <div className="mt-3 text-sm text-gray-600">Cargo</div>
        <div className="font-medium">{user?.role || '--'}</div>
      </div>
    </div>
  )
}
