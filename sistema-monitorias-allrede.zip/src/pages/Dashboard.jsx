import React, { useContext } from 'react'
import { UserContext } from '../App'

export default function Dashboard() {
  const { user } = useContext(UserContext)

  return (
    <div>
      <header className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Painel</h2>
        <div className="text-sm text-gray-600">{user?.displayName || 'Usuário de demonstração'}</div>
      </header>

      <section className="grid grid-cols-3 gap-4 mb-6">
        <Card title="Total de monitorias" value="--" />
        <Card title="Colaboradores com alerta" value="--" />
        <Card title="Retidos este mês" value="--" />
      </section>

      <section>
        <h3 className="font-semibold mb-2">Atalhos rápidos</h3>
        <div className="flex gap-3">
          <a href="/app/monitorias" className="px-4 py-3 bg-allredeMid text-white rounded">Nova Monitoria</a>
          <a href="/app/usuarios" className="px-4 py-3 bg-gray-100 rounded">Gerenciar Usuários</a>
        </div>
      </section>
    </div>
  )
}

function Card({ title, value }) {
  return (
    <div className="bg-white p-4 rounded shadow">
      <div className="text-sm text-gray-500">{title}</div>
      <div className="text-2xl font-bold mt-2">{value}</div>
    </div>
  )
}
