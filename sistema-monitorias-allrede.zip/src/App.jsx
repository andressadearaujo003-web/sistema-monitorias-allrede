import React, { useState, useEffect, createContext } from 'react'
import { Routes, Route } from 'react-router-dom'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import Monitorias from './pages/Monitorias'
import Usuarios from './pages/Usuarios'
import Perfil from './pages/Perfil'

export const UserContext = createContext(null)

export default function App() {
  const [user, setUser] = useState(null)

  useEffect(() => {
    // NOTE: For prototyping we won't attach firebase auth state listener here.
    // In production, use onAuthStateChanged(auth, user => setUser(user))
  }, [])

  return (
    <UserContext.Provider value={{ user, setUser }}>
      <div className="min-h-screen bg-gradient-to-b from-white to-gray-50">
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="/app/*" element={<ProtectedApp />} />
        </Routes>
      </div>
    </UserContext.Provider>
  )

  function ProtectedApp() {
    return (
      <div className="flex">
        <Sidebar />
        <main className="flex-1 p-6">
          <Routes>
            <Route path="" element={<Dashboard />} />
            <Route path="monitorias" element={<Monitorias />} />
            <Route path="usuarios" element={<Usuarios />} />
            <Route path="perfil" element={<Perfil />} />
          </Routes>
        </main>
      </div>
    )
  }
}

function Sidebar() {
  return (
    <aside className="w-72 bg-white shadow-lg p-6">
      <div className="flex items-center gap-3 mb-6">
        <img src="/idehR-ka1b_logos.png" alt="Allrede" className="w-36" />
      </div>
      <nav className="flex flex-col gap-2 text-sm">
        <a href="/app" className="px-3 py-2 rounded hover:bg-gray-100">Dashboard</a>
        <a href="/app/monitorias" className="px-3 py-2 rounded hover:bg-gray-100">Monitorias</a>
        <a href="/app/usuarios" className="px-3 py-2 rounded hover:bg-gray-100">Usuários</a>
        <a href="/app/perfil" className="px-3 py-2 rounded hover:bg-gray-100">Meu Perfil</a>
      </nav>
    </aside>
  )
}
